# TASK1: Import required libraries and read the dataset
import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html

# Read airline data directly from online URL
airline_data = pd.read_csv('https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/airline_data.csv',
                           encoding="ISO-8859-1",
                           dtype={'Div1Airport': str, 'Div1TailNum': str,
                                  'Div2Airport': str, 'Div2TailNum': str})

# Random sample 500 data points, random state fixed for reproducibility
data = airline_data.sample(n=500, random_state=42)

# Create pie chart figure
fig = px.pie(data, values='Flights', names='DistanceGroup',
             title='Distance group proportion by flights')

# TASK2: Create dash app & layout skeleton
app = Dash(__name__)

app.layout = html.Div(children=[
    # TASK3: Application Title
    html.H1('Airline Dashboard',
            style={'textAlign': 'center', 'color': '#503D36', 'font-size': 40}),
    # TASK4: Application Description paragraph
    html.P('Proportion of distance group (250 mile distance interval group) by flights.',
           style={'textAlign': 'center', 'color': '#F57241'}),
    # TASK5: Add pie chart graph component
    dcc.Graph(figure=fig),
])

# TASK6: Run application
if __name__ == '__main__':
    app.run(debug=False)