# TASK 4 Step 1: Import libraries and read dataset
import pandas as pd
import plotly.express as px
import dash
from dash import dcc
from dash import html
from dash.dependencies import Input, Output

airline_data = pd.read_csv('https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/airline_data.csv',
                            encoding = "ISO-8859-1",
                            dtype={'Div1Airport': str, 'Div1TailNum': str,
                                   'Div2Airport': str, 'Div2TailNum': str})

# TASK4 Step2: Create Dash app and layout
app = dash.Dash(__name__)

app.layout = html.Div(children=[
    # H1 Title, font-size 40
    html.H1('Total number of flights to the destination state split by reporting airline',
            style={'textAlign': 'center', 'color': '#503D36', 'font-size':40}),
    # Input component: id=input-year, default=2010, number type
    html.Div(["Input Year: ",
        dcc.Input(id='input-year', value='2010', type='number',
                  style={'height':'50px','font-size':35}),
        ],
        style={'font-size':40}),
    html.Br(),
    html.Br(),
    # Output Graph component id = bar-plot
    html.Div(dcc.Graph(id='bar-plot')),
])

# TASK4 Step3: Callback decorator
@app.callback(
    Output(component_id='bar-plot', component_property='figure'),
    Input(component_id='input-year', component_property='value')
)

# TASK4 Step4: Callback graph function
def get_graph(entered_year):
    # filter selected year
    df = airline_data[airline_data['Year'] == int(entered_year)]
    # Group by destination state AND reporting airline (REQUIRED by task)
    bar_data = df.groupby(['DestState','Reporting_Airline'])['Flights'].sum().reset_index()

    fig = px.bar(bar_data,
                 x='DestState',
                 y='Flights',
                 color='Reporting_Airline',
                 title='Flights to Destination State')
    fig.update_layout(xaxis_title="DestState", yaxis_title="Flights")
    return fig

# TASK4 Step5: Run app
if __name__ == '__main__':
    app.run(debug=False)