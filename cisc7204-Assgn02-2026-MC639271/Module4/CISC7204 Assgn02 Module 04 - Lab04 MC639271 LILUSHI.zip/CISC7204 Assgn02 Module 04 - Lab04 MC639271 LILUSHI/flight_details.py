# TASK1: Import libraries and read dataset
import pandas as pd
import plotly.graph_objects as go
import dash
from dash import dcc
from dash import html
from dash.dependencies import Input, Output
import plotly.express as px

airline_data = pd.read_csv(
    'https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/airline_data.csv',
    encoding = "ISO-8859-1",
    dtype={'Div1Airport': str, 'Div1TailNum': str,
           'Div2Airport': str, 'Div2TailNum': str})

# TASK2 & TASK3: Create Dash app + Layout
app = dash.Dash(__name__)

app.layout = html.Div(children=[
    # H1 Title
    html.H1('Flight Details Statistics Dashboard',
            style={'textAlign': 'center', 'color': '#503D36', 'font-size': 35}),

    # Year Input Component
    html.Div(["Input Year: ",
        dcc.Input(id='input-year', value=2010, type='number',
                  style={'height':'35px','font-size':30})
        ],
        style={'font-size':30}),

    html.Br(),
    html.Br(),

    # Segment1: carrier-plot + weather-plot (side by side)
    html.Div([
        html.Div(dcc.Graph(id='carrier-plot')),
        html.Div(dcc.Graph(id='weather-plot'))
    ], style={'display': 'flex'}),

    # Segment2: nas-plot + security-plot (side by side)
    html.Div([
        html.Div(dcc.Graph(id='nas-plot')),
        html.Div(dcc.Graph(id='security-plot'))
    ], style={'display': 'flex'}),

    # Segment3: late-aircraft single plot, width=65%
    html.Div([
        html.Div(dcc.Graph(id='late-plot'))
    ], style={'width':'65%'})
])

# TASK4: Supporting compute_info function
def compute_info(airline_data, entered_year):
    # Filter selected year
    df = airline_data[airline_data['Year'] == int(entered_year)]

    # Group by Month AND Reporting_Airline, compute mean delay for each delay type
    avg_car = df.groupby(['Month','Reporting_Airline'])['CarrierDelay'].mean().reset_index()
    avg_weather = df.groupby(['Month','Reporting_Airline'])['WeatherDelay'].mean().reset_index()
    avg_NAS = df.groupby(['Month','Reporting_Airline'])['NASDelay'].mean().reset_index()
    avg_sec = df.groupby(['Month','Reporting_Airline'])['SecurityDelay'].mean().reset_index()
    avg_late = df.groupby(['Month','Reporting_Airline'])['LateAircraftDelay'].mean().reset_index()

    return avg_car, avg_weather, avg_NAS, avg_sec, avg_late

# TASK5 & TASK6: Callback decorator + callback function
@app.callback(
    [Output(component_id='carrier-plot', component_property='figure'),
     Output(component_id='weather-plot', component_property='figure'),
     Output(component_id='nas-plot', component_property='figure'),
     Output(component_id='security-plot', component_property='figure'),
     Output(component_id='late-plot', component_property='figure')
    ],
    Input(component_id='input-year', component_property='value')
)

def get_graph(entered_year):
    avg_car, avg_weather, avg_NAS, avg_sec, avg_late = compute_info(airline_data, entered_year)

    # Line chart 1: Carrier Delay
    carrier_fig = px.line(avg_car, x='Month', y='CarrierDelay', color='Reporting_Airline',
                          title='Average carrier delay time (minutes) by airline')
    # Line chart 2: Weather Delay
    weather_fig = px.line(avg_weather, x='Month', y='WeatherDelay', color='Reporting_Airline',
                          title='Average weather delay time (minutes) by airline')
    # Line chart3: NAS Delay
    nas_fig = px.line(avg_NAS, x='Month', y='NASDelay', color='Reporting_Airline',
                      title='Average NAS delay time (minutes) by airline')
    # Line chart4: Security Delay
    sec_fig = px.line(avg_sec, x='Month', y='SecurityDelay', color='Reporting_Airline',
                      title='Average security delay time (minutes) by airline')
    # Line chart5: Late Aircraft Delay
    late_fig = px.line(avg_late, x='Month', y='LateAircraftDelay', color='Reporting_Airline',
                       title='Average late aircraft delay time (minutes) by airline')

    return [carrier_fig, weather_fig, nas_fig, sec_fig, late_fig]

# TASK6: Run the application
if __name__ == '__main__':
    app.run(debug=False)